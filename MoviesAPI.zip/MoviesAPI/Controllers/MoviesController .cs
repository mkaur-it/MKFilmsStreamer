﻿using Microsoft.AspNetCore.Mvc;
using System.Text.RegularExpressions;
using MKFilmsStreamer.API;
using MKFilmsStreamer.Models;
using MoviesAPI.Repositories;
using System.Reflection;
using Newtonsoft.Json;


namespace MKFilmsStreamer.MoviesAPI.Controllers
{
    [ApiController]
    [Route("api/movies")] // Base route for the controller
    public class MoviesController : ControllerBase
    {
        [HttpGet("load/moviesFromExternalAPI")]
        public async Task<IActionResult> LoadAllMovies()
        {
            // Assuming Fetch.GetMovieTrends is called somewhere to populate Fetch.posterSet
            await Fetch.GetMovieTrends();

            // Check if posterSet is populated
            if (Fetch.posterSet != null && Fetch.posterSet.results != null && Fetch.posterSet.results.Count > 0)
            {
                // Return the list of movies if available
                return Ok(Fetch.posterSet.results);
            }
            else
            {
                // Return a "Not Found" response if no movies are available
                return NotFound("No movies found.");
            }
        }
        [HttpGet("load/moviesFromLocalAPI")]
        public IActionResult GetAllMovies()
        {
            List<Poster> allMovies = MovieRepository.GetMovies();

            if (allMovies != null && allMovies.Count > 0)
            {
                return Ok(allMovies);
            }
            else
            {
                return NotFound("No movies found.");
            }
        }
        [HttpGet("trends")]
        public async Task<IActionResult> GetMovieTrends()
        {
            await Fetch.GetMovieTrends();
            return Ok(Fetch.posterSet); 
        }

        [HttpGet("search")]
        public async Task<IActionResult> Search(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return BadRequest("Search query is empty.");

            await Fetch.Search(query);
            return Ok(Fetch.resultSet); // Returning the resultSet as an example
        }

        [HttpGet("{movieID}/fromExternalAPI")]
        public async Task<IActionResult> GetMovieDetails(string movieID)
        {
            if (string.IsNullOrWhiteSpace(movieID))
                return BadRequest("Movie ID is empty.");

            await Fetch.MovieDetails(movieID);
            return Ok(Fetch.movie); // Returning the movie details as an example
        }
        [HttpGet("{movieID}/fromLocalAPI")]
        public async Task<IActionResult> GetLocalMovieDetails(int movieID)
        {
            
            if(movieID <= 0)
                return BadRequest("Invalid movie ID.");

            Poster movie = MovieRepository.GetMovieById(movieID);

            if (movie != null)
            {
                return Ok(movie); // Returning the movie details 
            }
            else
            {
                return NotFound($"No movie found with ID {movieID}. Please verify the movie ID again.");
            }
        }


        [HttpGet("actors/{actorID}")]
        public async Task<IActionResult> GetActorDetails(string actorID)
        {
            if (string.IsNullOrWhiteSpace(actorID))
                return BadRequest("Actor ID is empty.");

            await Fetch.GetActorDetails(actorID);
            return Ok(new
            {
                Actor = Fetch.actor,
                SocialMedia = Fetch.actorSocialMediaSet,
                ImageGallery = Fetch.actorImageGallery,
                KnownPosters = Fetch.actorKnownPosters
            }); // Returning actor details, social media, image gallery, and known posters
        }

        [HttpGet("{movieID}/similar")]
        public async Task<IActionResult> GetSimilarMovies(string movieID)
        {
            if (string.IsNullOrWhiteSpace(movieID))
                return BadRequest("Movie ID is empty.");

            await Fetch.MovieDetails(movieID); // Fetching movie details first
            // await Fetch.GetSimilarMovies(movieID);
            return Ok(Fetch.similarMovies); // Returning similar movies
        }
        [HttpPost]
        public async Task<IActionResult> CreateMovie([FromBody] Poster movie, [FromServices] ILogger<MoviesController> logger)
        {
            if (movie == null)
            {
                logger.LogError("Invalid request payload");
                return BadRequest(new { ErrorMessage = "Invalid request payload" });
            }

            // Log the received movie object (for debugging purposes)
            logger.LogInformation($"Received movie: {JsonConvert.SerializeObject(movie)}");

            // Check if all fields are empty or have default values
            if (AllFieldsEqualToDefault(movie))
            {
                logger.LogError("No valid movie information provided. Nothing added.");
                return BadRequest("No valid movie information provided. Nothing added.");
            }
            else
            {
                string result = MovieRepository.AddMovie(movie);
                if (result.StartsWith("Movie"))
                {
                    logger.LogInformation($"Movie added successfully. Result: {result}");
                    return CreatedAtAction(nameof(GetMovieDetails), new { movieID = movie.id }, new { MovieDetails = movie, SuccessMessage = result });
                }
                else
                {
                    logger.LogError($"Movie addition failed. Result: {result}");
                    return BadRequest(new { ErrorMessage = result });
                }
            }
        }



        [HttpPut("{movieID}")]
        public IActionResult UpdateMovie(int movieID, [FromBody] Poster updatedMovie)
        {
            string updateResult = MovieRepository.UpdateMovie(movieID, updatedMovie);

            if (updateResult.Contains("updated successfully"))
            {
                return Ok(updateResult);
            }
            else
            {
                return NotFound(updateResult);
            }
        }


        [HttpDelete("{movieID}")]
        public IActionResult DeleteMovie(int movieID)
        {
            if (movieID <= 0)
                return BadRequest("Invalid movie ID");

            string deleteResult = MovieRepository.DeleteMovie(movieID);

            return Ok(deleteResult);
        }
        private bool AllFieldsEqualToDefault(Poster movie)
        {
            // Check specific conditions for id, title, and overview
            if (movie.id == 0 && movie.title == "string" && movie.overview == "string")
            {
                // If conditions are met, return true to indicate that all fields are default
                return true;
            }

            // Create a new instance of Poster with default values
            Poster defaultMovie = new Poster
            {
                adult = false,
                backdrop_path = "string",
                id = 0,
                title = "string",
                original_language = "string",
                original_title = "string",
                overview = "string",
                poster_path = "string",
                media_type = "string",
                genre_ids = new List<int> { 0 },
                popularity = 0,
                release_date = "string",
                video = false,
                vote_average = 0,
                vote_count = 0,
                name = "string",
                original_name = "string",
                first_air_date = "string",
                origin_country = new List<string> { "string" }
            };

            // Serialize both objects to JSON strings
            string movieJson = JsonConvert.SerializeObject(movie);
            string defaultMovieJson = JsonConvert.SerializeObject(defaultMovie);

            // Compare the JSON strings to check if they are equal
            return movieJson == defaultMovieJson;
        }

    }
}