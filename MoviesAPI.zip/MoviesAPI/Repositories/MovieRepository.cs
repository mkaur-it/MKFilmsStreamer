﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using MKFilmsStreamer.API;
using MKFilmsStreamer.Models;

namespace MoviesAPI.Repositories
{
    public class MovieRepository
    {
        // Use Fetch.posterSet as the source of movie data
        private static List<Poster> movies = Fetch.posterSet?.results ?? new List<Poster>();

        public static List<Poster> GetMovies()
        {
            return movies;
        }

        public static string AddMovie(Poster movie)
        {
            int providedID = movie.id;
            // Check if the provided ID is 0
            if (movie.id == 0)
            {
                // Assign the next available ID
                movie.id = movies.Any() ? movies.Max(x => x.id) + 1 : 1;
                movies.Add(movie);

                return $"Movie with ID {movie.id} and title '{movie.title}' added successfully.";
            }
            else
            {
                // Check if the provided ID already exists
                Poster existingMovieWithId = GetMovieById(movie.id);

                if (existingMovieWithId != null)
                {
                    // If same title already exists, display a message
                    if (existingMovieWithId.title == movie.title)
                    {
                        return $"Movie with ID {movie.id} and title '{movie.title}' already exists. No duplicates added.";
                    }
                    else
                    {
                        // If the same ID exists but with a different title, generate the next available ID
                        int nextAvailableId = movies.Any() ? movies.Max(x => x.id) + 1 : 1;

                        // Assign the new ID and add the movie
                   
                        movie.id = nextAvailableId;
                        movies.Add(movie);

                        return $"Movie with Unique ID {nextAvailableId} assigned as provided ID {providedID} already exists with a different title. Movie '{movie.title}' added successfully.";
                    }
                }
                else
                {
                    // If the provided ID doesn't exist, add the movie with the provided ID
                    movies.Add(movie);
                    return $"Movie with ID {movie.id} and title '{movie.title}' added successfully.";
                }
            }
        }




        public static string UpdateMovie(int movieID, Poster updatedMovie)
        {
            Poster existingMovie = GetMovieById(movieID);
            if (existingMovie != null)
            {
                // Update all properties of existingMovie with the values from updatedMovie
                existingMovie.title = updatedMovie.title;
                existingMovie.overview = updatedMovie.overview;
                existingMovie.adult = updatedMovie.adult;
                existingMovie.backdrop_path = updatedMovie.backdrop_path;
                existingMovie.id = movieID;
                existingMovie.original_language = updatedMovie.original_language;
                existingMovie.original_title = updatedMovie.original_title;
                existingMovie.poster_path = updatedMovie.poster_path;
                existingMovie.media_type = updatedMovie.media_type;
                existingMovie.genre_ids = updatedMovie.genre_ids;
                existingMovie.popularity = updatedMovie.popularity;
                existingMovie.release_date = updatedMovie.release_date;
                existingMovie.video = updatedMovie.video;
                existingMovie.vote_average = updatedMovie.vote_average;
                existingMovie.vote_count = updatedMovie.vote_count;
                existingMovie.name = updatedMovie.name;
                existingMovie.original_name = updatedMovie.original_name;
                existingMovie.first_air_date = updatedMovie.first_air_date;
                existingMovie.origin_country = updatedMovie.origin_country;

                return $"Movie with movie id {movieID} and title '{existingMovie.title}' updated successfully.";
            }

            return $"No movie found with ID {movieID}. Please verify the movie ID again.";
        }



        public static string DeleteMovie(int id)
        {
            Poster movieToDelete = GetMovieById(id);
            if (movieToDelete != null)
            {
                movies.Remove(movieToDelete);
                return $"Movie with movie id {id} and title '{movieToDelete.title}'  deleted successfully.";
            }

            return $"No movie found with ID {id}. Please verify the movie ID again.";

        }

        public static Poster GetMovieById(int id)
        {
            return movies.FirstOrDefault(x => x.id == id);
        }
    }
}
